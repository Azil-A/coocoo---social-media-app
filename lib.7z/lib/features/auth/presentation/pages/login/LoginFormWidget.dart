// // import 'dart:math';

// import 'package:coocoo/features/auth/presentation/blocs/auth_cubit.dart';
// import 'package:coocoo/features/auth/presentation/helpers/Validators.dart';
// import 'package:coocoo/features/post/presentation/pages/home_screen.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';

// class LoginFormWidget extends StatefulWidget {
//     final void Function()? onTap;
//   LoginFormWidget({super.key,required this.onTap});

//   @override
//   State<LoginFormWidget> createState() => _LoginFormWidgetState();
// }

// class _LoginFormWidgetState extends State<LoginFormWidget> {


  
//   final TextEditingController email = TextEditingController();

//   final TextEditingController password = TextEditingController();

//   final GlobalKey<FormState> _formkey = GlobalKey<FormState>();

//   void _submitForm() {
//     if (_formkey.currentState!.validate()) {
//       // ScaffoldMessenger.of(_formkey.currentContext!).showSnackBar(SnackBar(content:Text('form submitted successfully')));
//       print('email :${email.text}');
//       print('password :${password.text}');
//       final authCubit = context.read<AuthCubit>();
//       if(!email.text.isEmpty && !password.text.isEmpty){
//         authCubit.login(email.text,password.text);
//         ScaffoldMessenger.of(_formkey.currentContext!).showSnackBar(SnackBar(content:Text('successfully logged-in')));
//         // Navigator.of(context).pushNamed('/home');
//         Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => HomeScreen()));
//       }
//       else{
//         ScaffoldMessenger.of(_formkey.currentContext!).showSnackBar(SnackBar(content:Text('please enter both email and password')));
//       }
//     }
//   }

//   // void dispose(){
//   //   email.dispose();
//   //   password.dispose();
//   //   super.dispose();
//   // }

//   @override
//   Widget build(BuildContext context) {
//     return 
//   }


// }

import 'package:coocoo/features/auth/presentation/pages/login/LoginMainScreen.dart';
import 'package:coocoo/features/auth/presentation/pages/login/SignUpMainScreen.dart';
import 'package:flutter/material.dart';

class Authpage extends StatefulWidget {
  const Authpage({super.key});

  @override
  State<Authpage> createState() => _AuthpageState();
}

class _AuthpageState extends State<Authpage> {

  bool showLoginPage = true;


  void togglePages(){
    setState(() {
      showLoginPage=!showLoginPage;
    });
  }

  @override
  Widget build(BuildContext context) {
    if(showLoginPage){
      return LoginMainScreen(
        onTap: togglePages,
      );
    }
    else {
      return SignupMainScreen(onTap: togglePages,);
    }
  }
}
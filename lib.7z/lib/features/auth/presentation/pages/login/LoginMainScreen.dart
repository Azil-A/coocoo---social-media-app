import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:coocoo/features/auth/presentation/blocs/auth_cubit.dart'; // Import your AuthCubit
import 'package:coocoo/features/auth/presentation/helpers/Validators.dart'; // Import your Validators

class LoginMainScreen extends StatefulWidget {
  final VoidCallback onTap; // Added onTap callback

  const LoginMainScreen({super.key, required this.onTap}); // Required parameter

  @override
  State<LoginMainScreen> createState() => _LoginMainScreenState();
}

class _LoginMainScreenState extends State<LoginMainScreen> {
  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();
  final TextEditingController email = TextEditingController();
  final TextEditingController password = TextEditingController();

  void _submitForm() {
    if (_formkey.currentState!.validate()) {
      print('email: ${email.text}');
      print('password: ${password.text}');
      final authCubit = context.read<AuthCubit>();
      if (email.text.isNotEmpty && password.text.isNotEmpty) {
        authCubit.login(email.text, password.text);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Successfully logged in')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Please enter both email and password')),
        );
      }
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff242634),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Form(
                  key: _formkey,
                  child: Column(
                    children: [
                      SizedBox(height: 50),
                      SizedBox(
                        width: 250,
                        child: Text(
                          'Login Account',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 28),
                        ),
                      ),
                      SizedBox(height: 86),
                      TextFormField(
                        controller: email,
                        style: TextStyle(color: Colors.white),
                        keyboardType: TextInputType.emailAddress,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: Validators().validateEmail,
                        decoration: _buildInputDecoration('Email', Icons.email),
                      ),
                      SizedBox(height: 16),
                      TextFormField(
                        controller: password,
                        obscureText: true,
                        style: TextStyle(color: Colors.white),
                        keyboardType: TextInputType.visiblePassword,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: Validators().validatePassword,
                        decoration: _buildInputDecoration('Password', Icons.lock),
                      ),
                      SizedBox(height: 16),
                      Container(
                        height: 50,
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color.fromARGB(255, 217, 81, 8),
                          ),
                          onPressed: _submitForm,
                          child: Text('Login', style: TextStyle(color: Colors.white)),
                        ),
                      ),
                      SizedBox(height: 50),
                      TextButton(
                        onPressed: widget.onTap, // Use the passed onTap callback
                        child: Text('Register', style: TextStyle(color: Color(0XFFF15900), fontSize: 25)),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  InputDecoration _buildInputDecoration(String label, IconData suffixIcon) {
    return InputDecoration(
      suffixIcon: Icon(suffixIcon, color: Color(0xff949494)),
      enabledBorder:
          OutlineInputBorder(borderSide: BorderSide(color: Color(0x35949494))),
      focusedBorder:
          OutlineInputBorder(borderSide: BorderSide(color: Colors.white)),
      fillColor: Color(0xaa494a59),
      filled: true,
      labelText: label, // Changed from label to labelText
      labelStyle:
          TextStyle(color: Color(0xff949494)),
      border:
          OutlineInputBorder(borderRadius:
          BorderRadius.circular(10)),
    );
  }
}
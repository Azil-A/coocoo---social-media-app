// // import 'dart:math';

// import 'package:coocoo/features/auth/presentation/helpers/Validators.dart';
// import 'package:flutter/material.dart';

// class SignUpFormWidget extends StatelessWidget {
//   final void Function() onTap;
//   SignUpFormWidget({super.key, required this.onTap});

//   final GlobalKey<FormState> _formkey = GlobalKey<FormState>();

  
//   @override
//   Widget build(BuildContext context) {
//     return 
//   }

  

// }

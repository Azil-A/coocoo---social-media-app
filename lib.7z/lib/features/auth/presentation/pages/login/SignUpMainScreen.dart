import 'package:coocoo/features/auth/presentation/blocs/auth_cubit.dart';
import 'package:coocoo/features/auth/presentation/helpers/Validators.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class SignupMainScreen extends StatefulWidget {
  final void Function() onTap;
 


  SignupMainScreen({super.key, required this.onTap});
  
  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();

  @override
  State<SignupMainScreen> createState() => _SignupMainScreenState();
}

class _SignupMainScreenState extends State<SignupMainScreen> {
   final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController PasswordController= TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();
  void _submitForm() {
    if (widget._formkey.currentState!.validate()) {
      
    final email = emailController.text;
    final name = nameController.text;
    final Password = PasswordController.text;
    final ConPassword = confirmPasswordController.text;
    final authCubit = context.read<AuthCubit>();
    if (name.isNotEmpty && Password.isNotEmpty && ConPassword == Password && email.isNotEmpty) {
       authCubit.register(name, email, Password);
       ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Form submitted successfully')),
      );
      } 
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff242634),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Form(
                  key: widget._formkey,
                  child: Column(
                    children: [
                      SizedBox(height: 50),
                      SizedBox(
                        width: 250,
                        child: Text(
                          'Create new account',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 28),
                        ),
                      ),
                      SizedBox(height: 16),
                      SizedBox(height: 50),
                      TextFormField(
                        controller:nameController,
                        style: TextStyle(color: Colors.white),
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: Validators().validateUsername,
                        decoration: _buildInputDecoration('Username', Icons.person),
                      ),
                      SizedBox(height: 16),
                      TextFormField(
                        controller: emailController,
                        style: TextStyle(color: Colors.white),
                        keyboardType: TextInputType.emailAddress,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: Validators().validateEmail,
                        decoration: _buildInputDecoration('Email', Icons.email),
                      ),
                      SizedBox(height: 16),
                      TextFormField(
                        style: TextStyle(color: Colors.white),
                        keyboardType: TextInputType.phone,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: Validators().validatePhone,
                        decoration: _buildInputDecoration('Phone', Icons.phone),
                      ),
                      SizedBox(height: 16),
                      TextFormField(
                        controller: PasswordController,
                        obscureText: true,
                        style: TextStyle(color: Colors.white),
                        keyboardType: TextInputType.visiblePassword,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: Validators().validatePassword,
                        decoration: _buildInputDecoration('Password', Icons.lock),
                      ),
                      TextFormField(
                        controller: confirmPasswordController,
                        obscureText: true,
                        style: TextStyle(color: Colors.white),
                        keyboardType: TextInputType.visiblePassword,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: Validators().validatePassword,
                        decoration: _buildInputDecoration('Password', Icons.lock),
                      ),
                      SizedBox(height: 16),
                      Container(
                        height: 50,
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color.fromARGB(255, 217, 81, 8),
                          ),
                          onPressed: () {
                            _submitForm();
                          },
                          child: Text('Create', style: TextStyle(color: Colors.white)),
                        ),
                      ),
                      SizedBox(height: 50),
                      TextButton(
                        onPressed: widget.onTap, // Correctly reference onTap
                        child: Text('Login', style: TextStyle(color: Color(0XFFF15900), fontSize: 25)),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  InputDecoration _buildInputDecoration(String label, IconData suffixIcon) {
    return InputDecoration(
      suffixIcon: Icon(suffixIcon, color: Color(0xff949494)),
      enabledBorder:
          OutlineInputBorder(borderSide: BorderSide(color: Color(0x35949494))),
      focusedBorder:
          OutlineInputBorder(borderSide: BorderSide(color: Colors.white)),
      fillColor: Color(0xaa494a59),
      filled: true,
      labelText:
          label, // Changed from label to labelText for better compatibility
      labelStyle:
          TextStyle(color: Color(0xff949494)), // Set label style separately
      border:
          OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
    );
  }
}